#!/bin/bash

curl -X POST -d '{"cmd":"ADD","dst-port":"1","dst-switch":"00:00:00:00:00:00:00:01","src-switch":"00:00:00:00:00:00:00:01","src-port":"1","requirement":"6.0"}' http://131.179.210.214:8080/wm/fdm/config/json

curl -X POST -d '{"cmd":"ADD","dst-port":"1","dst-switch":"00:00:00:00:00:00:00:02","src-switch":"00:00:00:00:00:00:00:02","src-port":"1","requirement":"6.0"}' http://131.179.210.214:8080/wm/fdm/config/json

curl -X POST -d '{"cmd":"ADD","dst-port":"1","dst-switch":"00:00:00:00:00:00:00:03","src-switch":"00:00:00:00:00:00:00:03","src-port":"1","requirement":"6.0"}' http://131.179.210.214:8080/wm/fdm/config/json

curl -X POST -d '{"cmd":"ADD","dst-port":"1","dst-switch":"00:00:00:00:00:00:00:07","src-switch":"00:00:00:00:00:00:00:04","src-port":"4","capacity":"5.0"}' http://131.179.210.214:8080/wm/fdm/config/json


curl -X POST -d '{"cmd":"ADD","dst-port":"2","dst-switch":"00:00:00:00:00:00:00:07","src-switch":"00:00:00:00:00:00:00:05","src-port":"4","capacity":"10.0"}' http://131.179.210.214:8080/wm/fdm/config/json

curl -X POST -d '{"cmd":"ADD","dst-port":"3","dst-switch":"00:00:00:00:00:00:00:07","src-switch":"00:00:00:00:00:00:00:06","src-port":"4","capacity":"5.0"}' http://131.179.210.214:8080/wm/fdm/config/json
