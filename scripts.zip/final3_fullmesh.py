from mininet.topo import Topo
from mininet.link import Link,TCLink
from mininet.util import makeNumeric, custom




class MyTopo( Topo ):
    "Simple topology with multiple links"

    def __init__( self ):
        Topo.__init__( self)


        dummyHost = self.addHost('dest')
        ship1Host =  self.addHost( 'ship1' )
        ship2Host =  self.addHost( 'ship2' )
        ship3Host =  self.addHost( 'ship3' )

 
        #ship3Host =  self.addHost( 'ship3' )
	ship1 = self.addSwitch( 's1' )
	#shipsome=self.addSwitch('s2')	
        ship2 = self.addSwitch( 's2' )
        ship3 = self.addSwitch( 's3' )
	sat1 = self.addSwitch( 's4' )
        sat2 = self.addSwitch( 's5' )
	sat3=self.addSwitch('s6')
	dest = self.addSwitch( 's7' )
        

#ship3 = self.addSwitch( 's7' )


        # h1, h2 = self.addHost( 'h1' ), self.addHost( 'h2' )
        # source = self.addSwitch( 's1' )
        # sat1 = self.addSwitch( 's2' )
        # sat2 = self.addSwitch( 's3' )
        # dest = self.addSwitch( 's4' )

#        for _ in range( n ):    
        
        self.addLink( ship1Host, ship1, bw=10)
        self.addLink( ship2Host, ship2, bw=10)
        self.addLink( ship3Host, ship3, bw=10)


        #self.addLink( ship3Host, ship3)
#    self.addLink( s3, h3,bw=20 )

        self.addLink(ship1,sat1,bw=100,delay='10ms')
        self.addLink(ship1,sat2,bw=100,delay='10ms')
        self.addLink(ship1,sat3,bw=100,delay='10ms')
        #self.addLink(ship1,sat3,bw=100,delay='20ms')

        self.addLink(ship2,sat1,bw=100,delay='10ms')
        self.addLink(ship2,sat2,bw=100,delay='10ms')
        self.addLink(ship2,sat3,bw=100,delay='10ms')
        #self.addLink(ship2,sat3,bw=100,delay='20ms')

        #self.addLink(ship3,sat1,bw=100,delay='10ms')
        #self.addLink(ship3,sat2,bw=100,delay='15ms')
        #self.addLink(ship3,sat3,bw=100,delay='20ms')

        self.addLink(ship3,sat1,bw=100,delay='10ms')
        self.addLink(ship3,sat2,bw=100,delay='10ms')
        self.addLink(ship3,sat3,bw=100,delay='10ms')


        self.addLink(sat1,dest,bw=100,delay='100ms')
        self.addLink(sat2,dest,bw=100,delay='100ms')
        self.addLink(sat3,dest,bw=100,delay='100ms')


	self.addLink( dummyHost, dest,bw=100)
        #self.addLink(sat3,dest,bw=100,delay='100ms')

topos = { 'mytopo': ( lambda: MyTopo() ) }

