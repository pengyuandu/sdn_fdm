#!/bin/bash

curl -X POST -d '{"cmd":"DELETE","dst-port":"1","dst-switch":"00:00:00:00:00:00:00:01","src-switch":"00:00:00:00:00:00:00:01","src-port":"1"}' http://131.179.210.214:8080/wm/fdm/config/json

curl -X POST -d '{"cmd":"DELETE","dst-port":"1","dst-switch":"00:00:00:00:00:00:00:02","src-switch":"00:00:00:00:00:00:00:02","src-port":"1"}' http://131.179.210.214:8080/wm/fdm/config/json

curl -X POST -d '{"cmd":"DELETE","dst-port":"1","dst-switch":"00:00:00:00:00:00:00:03","src-switch":"00:00:00:00:00:00:00:03","src-port":"1"}' http://131.179.210.214:8080/wm/fdm/config/json
